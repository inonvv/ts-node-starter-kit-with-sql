import { Employee } from "./types/employee.type";
import Db from "./utils/db";

async function main() {
    let employees: Employee[] | undefined = await Db.selectData('select * from Employee');
    console.log(employees);

    // let res = Db.insertData_NotSecure('Employee', { id: '666666666', first_name: 'Shayk', last_name: 'Osman', birthday: '1996-01-01' });
    // console.log(res);

    // let res2 = await Db.insertEmployee('InsertEmployee', { id: '999999999', first_name: 'Shayk', last_name: 'Osman', birthday: new Date('1996-01-01') });
    // console.log(res2);

    let res3 = await Db.deleteEmployees('DeleteEmployees');
    console.log(res3);
}

main();